const express = require("express");
const router = express.Router();
const db = require("../models");
const bcrypt = require("bcryptjs");
const users = require("../controllers/user")
const nodemailer = require('nodemailer');

/* BASE PATH */



// Choose FORM
router.get("/choose", (req, res) => {
    res.render("/", {user: req.session.currentUser});
});


// choose POST <- AUTHENTICATION
router.post("/choose", async (req, res) => {
    try {
        const foundUser = await db.User.findOne({ username: req.body.username });

        if(!foundUser){                                                                     // if user does not exist => error
            req.flash('error', "User does not exist");
            return res.redirect("login");
        }

        const match = await bcrypt.compare(req.body.password, foundUser.password);          // if user exist then compare login info with db

        if(!match){                                                                         //if login info doesn't match db
            req.flash('error', "Incorrect login info");
            return res.redirect("login");
        }

        req.session.currentUser = {                                                         // if login info match, create session for authentication
            username: foundUser.username,
            id: foundUser._id,
            currentevent: req.body.cecoevent,
        }
        console.log(req.session.currentUser.currentevent + " from choose controller");
        res.redirect("/")                                                                   // redirect to home after logged-in
    } catch(err) {
        req.flash('error', err);
        return res.redirect("404");                                                         // redirect to 404 Page if there is an error
    }
})



module.exports = router;
