const express = require("express");
const router = express.Router();
const path = require("path");
const db = require("../models");
var myDates = 1;
var dataMult;
var results = [];//{} is object [] is array (child of object)
//functions
function count(data){
  console.log(dataMult.category+" ......category in countFunction");
  console.log(dataMult.strike+" ......dataMult in countFunction");
  myDates = 1;
  for(let i =1;i<15;++i){
    if(eval("dataMult.strike" + i)===undefined){
    }else{
      ++myDates;
      //console.log(eval("req.body.strike" + i));
      
    }
  }
  console.log(myDates+" so many dates!!!!!");

  results.push({title:data.title,title2:data.title2,uniqueNum:data.uniqueNum,client:data.client,contactName:data.contactName,contactEmail:data.contactEmail,contactNumber:data.contactNumber,body: data.body,votes:data.votes,startmonth:data.startmonth,startday:data.startday,starttime:data.starttime,endmonth:data.endmonth,endday:data.startday,endtime:data.endtime,cecoevent:data.cecoevent,username:data.username,category:data.category,group:data.group,EntityToRent:data.EntityToRent,chargePeriod:data.chargePeriod,PeriodsRequired:data.PeriodsRequired,strike:data.strike,NumberRequired:data.NumberRequired,CostPerHour:data.CostPerHour},{timestamps:true,createdAt:data.createdAt});
  let et = "";
  let st ="";
if(myDates>1){
  for(let i =1; i<(myDates);++i){
    bt = eval("dataMult.starttime" + i);
    et = eval("dataMult.endtime" + i);
    st = eval("dataMult.strike" + i);
    results.push({title:data.title,title2:data.title2,uniqueNum:data.uniqueNum,client:data.client,contactName:data.contactName,contactEmail:data.contactEmail,contactNumber:data.contactNumber,body: data.body,votes:data.votes,startmonth:data.startmonth,startday:data.startday+i,starttime:bt,endmonth:data.endmonth,endday:data.startday+i,endtime:et,cecoevent:data.cecoevent,username:data.username,category:data.category,group:data.group,EntityToRent:data.EntityToRent,chargePeriod:data.chargePeriod,PeriodsRequired:data.PeriodsRequired,strike:st,NumberRequired:data.NumberRequired,CostPerHour:data.CostPerHour},{timestamps:true,createdAt:data.createdAt});
  }
  console.log(results);
}
return results;
}
  
// base route /

// Search route
router.get("/search", async (req, res) => {
  console.log(req.query.results)
  try {
    const results = await db.Post.find(
      { "title" : { $regex : new RegExp(req.query.results, "i") } }
    );
    console.log(results)
    const context = {
      results: results,

    };
    res.render("posts/search.ejs", context);
  } catch (error) {
    console.log(error)
    req.flash('error', error);
    return res.redirect("404");                                                          // redirect to 404 Page if there is an error
  }
});

// cecoevent index route
router.get("/r", async (req, res) => {
  try {
    const foundPosts = await db.Post.find({cecoevent: req.params.cecoevent});
    const allEvent_Names = await db.Post.distinct("cecoevent");
    const context = {
      posts: foundPosts,
      cecoevents: allEvent_Names,
    };
    res.render("posts/subs", context);
  } catch (error) {
    req.flash('error', error);
    return res.redirect("404");                                                          // redirect to 404 Page if there is an error
  }
});

// cecoevent show route
router.get("/r/:cecoevent", async (req, res) => {
  try {
    const foundPosts = await db.Post.find({cecoevent: req.params.cecoevent});
    const allEvent_Names = await db.Post.distinct("cecoevent");
    const context = {
      posts: foundPosts,
      cecoevents: allEvent_Names,
    };
    res.render("/", context);
  } catch (error) {
    req.flash('error', error);
    return res.redirect("404");                                                          // redirect to 404 Page if there is an error
  }
});

// new route
router.get("/newPost", (req, res) => {
  try {
    const context = {
    }
    res.render("posts/new.ejs", context);
  } catch (error) {
    req.flash('error', "Cost Item must be between 4-250 characters. Notes must be between 4-5000 characters. Event_Names must be between 4-100 characters.");
    return res.redirect("404");                                                          // redirect to 404 Page if there is an error
  }
});


// new comment route
router.get("/:id/newComment", async (req, res) => {
  try {
    const postID = await db.Post.findById(req.params.id);
    const context = {
      user: req.session.currentUser,
      post: postID
    }
    res.render("comments/new.ejs", context);
  } catch (error) {
    req.flash('error', "comment must be between 2-1000 characters.");
    return res.redirect("404");                                                          // redirect to 404 Page if there is an error
  }
});

// Create comment route
router.post("/comments", async (req, res) => {
  try {
    const createdComment = await db.Comment.create(req.body);
    const foundUser = await db.User.findById(req.body.user);
    const foundPost = await db.Post.findById(req.body.post);

    foundUser.comments.push(createdComment);
    await foundUser.save();

    foundPost.comments.push(createdComment);
    await foundPost.save();

    //res.redirect(`/posts/${foundPost.id}`);
    res.redirect(`/`);//posts/r/${req.body.cecoevent}`);
  } catch (error) {
    console.log(error);
    req.flash('error', error);
    return res.redirect("404");                                                          // redirect to 404 Page if there is an error
  }
});


// SHOW COST FORM create post route/ which activates  when we show the costform We need both / & /posts
router.post("/", async (req, res) => {
  
  const foundUser = await db.User.findById(req.body.user);
    const username = foundUser.username;
    req.body.username = username;
    //req.body.EntityToRent = req.body.EntityToRent10;
    dataMult = req.body;
  if(req.body.category !== "chooseEvent"){//else we just go to the event below
    let returnData = count(dataMult);
    if(myDates!="1"){//numRec != 0) {
      console.log("ooooo im in the insertmany loop!00!");
      const datasave = await count(req.body);
      console.log(" shallow end  ......."+returnData[0]);
      
      try {//create can do multiple!!! controlled by vote number
        console.log(" deep inside ......trying to save multiple records.");//+dataMult);
        const foundUser = await db.User.findById(req.body.user);
        const username = foundUser.username;
        console.log(" user inside ......."+username);
        //datasave.username = username;
        const createdPost = await db.Post.create(returnData); //where "post" is the name of the collection
        console.log(" creating post from post.js 175");
        foundUser.posts.push(createdPost);
        await foundUser.save();
        res.redirect(`/`);//posts/r/${req.body.cecoevent}`);
        
      } catch (error) {
        /*console.log(error);
        req.flash('error1', "Name of Event must be between 2-50 characters");
        req.flash('error2', "Cost_Name must be between 2-50 characters");
        req.flash('error3', "Context must be between 2-1000 characters");*/
        return res.redirect("/"); 
                                                                  // redirect to index Page with error msgs if there is an error
      }
    }else{
    if(req.body.category !== "chooseEvent" && req.body.startmonth !== "Hide Form"  && req.body.startmonth !== "Show Form"){
      //count(dataMult);
      //req.body.group = req.body.group2;
      //req.body.category = req.body.category2;
      console.log("Trying to save one record        00000000011001"+req.body.group);
      const createdPost = await db.Post.create(req.body);
      
      foundUser.posts.push(createdPost);
      
    await foundUser.save();
  }
}
  }//else{

  

    const foundPosts = await db.Post.find({});//cecoevent: req.params.cecoevent});
    const context = {
      posts: foundPosts,
      user: req.session.currentUser,
      currentevent: req.body.cecoevent,
      currenthide: req.body.startmonth,
    };
  if(req.body.category !== "chooseEvent" && req.body.startmonth !== "Hide Form"  && req.body.startmonth !== "Show Form"){
    try {//this updates the front end
      console.log(context.currentevent + " from post142");// + context.posts[0].body);
      res.render("posts/index.ejs", {posts: foundPosts, user: req.session.currentUser, currentevent: req.body.cecoevent, currenthide: req.body.startmonth});//posts/r/${req.body.cecoevent}`);redirect
    } catch (error) {
      console.log(error);
      req.flash('error1', "Name of Event must be between 2-50 characters");
      req.flash('error2', "Cost_Name must be between 2-50 characters");
      req.flash('error3', "Context must be between 2-1000 characters");
      return res.redirect("/");                                                             // redirect to index Page with error msgs if there is an error
    }
  } else {
    try {
     
      console.log(req.body.startmonth + " pick event from post.js 119: " + req.body.cecoevent);
      
      //res.render("/posts");
      res.render("posts/index.ejs", {posts: foundPosts, user: req.session.currentUser, currentevent: req.body.cecoevent, currenthide: req.body.startmonth});
      //posts/r/${req.body.cecoevent}`);
    } catch (error) {
      console.log(error);
      return res.redirect("/");                                                             // redirect to index Page with error msgs if there is an error
    }
}
});
// end create post route= /
// create post route= /posts is maybe not used???????????
router.post("/posts", async (req, res) => {
  console.log("inside the router/post(/posts area!!!");
  const numRec = req.body.votes;

  if(req.body.category == "chooseEvent"){
    try {
      const foundUser = await db.User.findById(req.body.user);
      const username = foundUser.username;
      req.body.username = username;
      const createdPost = await db.Post.create(req.body);
      console.log(req.body.choosececoevent + " pick event from post.js 140");
      foundUser.posts.push(createdPost);
      await foundUser.save();
      res.body.currentevent = req.body.cecoevent;
      res.redirect(`/`);//posts/r/${req.body.cecoevent}`);
    } catch (error) {
      console.log(error);
      return res.redirect("/");                                                             // redirect to index Page with error msgs if there is an error
    }
  } else {
    if(req.body.votes == "0"){
  try {
    const foundUser = await db.User.findById(req.body.user);
    const username = foundUser.username;
    req.body.username = username;
    const createdPost = await db.Post.create(req.body); //where "post" is the name of the collection
    console.log(createdPost +" creating post from post.js 155");
    foundUser.posts.push(createdPost);
    await foundUser.save();
    res.redirect(`/`);//posts/r/${req.body.cecoevent}`);
  } catch (error) {
    console.log(error);
    req.flash('error1', "Name of Event must be between 2-50 characters");
    req.flash('error2', "Cost_Name must be between 2-50 characters");
    req.flash('error3', "Context must be between 2-1000 characters");
    return res.redirect("/");                                                             // redirect to index Page with error msgs if there is an error
  }
} else {
  try {//create can do multiple!!! controlled by vote number
    //count();
    console.log(" NOT WORKING im in the insermany loop!11!");
    /*const foundUser = await db.User.findById(req.body.user);
    const username = foundUser.username;
    req.body.username = username;
    const createdPost = await db.Post.create(req.body); //where "post" is the name of the collection
    console.log(createdPost +" creating post from post.js 155");
    foundUser.posts.push(createdPost);
    await foundUser.save();
    res.redirect(`/`);//posts/r/${req.body.cecoevent}`);
    */
  } catch (error) {
    /*console.log(error);
    req.flash('error1', "Name of Event must be between 2-50 characters");
    req.flash('error2', "Cost_Name must be between 2-50 characters");
    req.flash('error3', "Context must be between 2-1000 characters");
    return res.redirect("/"); 
    */                                                            // redirect to index Page with error msgs if there is an error
  }
}
}
});
// end create post route= /posts

// show
router.get("/:id", async (req, res) => {
  try {
    const foundPost = await db.Post.findById(req.params.id);
    const allEvent_Names = await db.Post.distinct("cecoevent");
    const foundComments = [];
    for (let i = 0; i < foundPost.comments.length; i++) {
      const comment = await db.Comment.findById(foundPost.comments[i]);
      const user = await db.User.findById(comment.user);
      foundComments.push([comment, user]);
    }

    const context = {
      post: foundPost,
      cecoevents: allEvent_Names,
      user: req.session.currentUser,
      comments: foundComments,
    };
    res.render("posts/show", context);
  } catch (error) {
    req.flash('error', error);
    return res.redirect("404");                                                          // redirect to 404 Page if there is an error
  }
});

// edit form
router.get("/:id/edit", async (req, res) => {
  try {
    const foundPost = await db.Post.findById(req.params.id);
    const context = {
      post: foundPost,
      user: req.session.currentUser,
    };
    console.log(foundPost)
    res.render("posts/edit.ejs", context);
  } catch (error) {
    req.flash('error', error);
    return res.redirect("404");                                                          // redirect to 404 Page if there is an error
  }
});

// update
router.put("/:id", async (req, res) => {
  try {
    const foundPost = await db.Post.findByIdAndUpdate(req.params.id, req.body, { new: true });
    //res.redirect(`/posts/${foundPost._id}`);
    res.redirect(`/`);//`/posts/r/${req.body.cecoevent}`
  } catch (error) {
    req.flash('error', error);
    return res.redirect("404");                                                          // redirect to 404 Page if there is an error
  }
});

// delete
router.delete("/:id", async (req, res) => {
  try {
    // deletes post from OPs post history
    const foundPost = await db.Post.findById(req.params.id);
    const foundUser = await db.User.findById(foundPost.user);
    for (let i = 0; i < foundUser.posts.length; i++) {
      if (foundUser.posts[i] == req.params.id) {
        foundUser.posts.splice(i, 1);
        await foundUser.save();
      }
    }

    // deletes comments from commenters history
    const foundComments = foundPost.comments;
    for (let i = 0; i < foundComments.length; i++) {
      const singleComment = await db.Comment.findById(foundComments[i]);
      const userComment = await db.User.findById(singleComment.user);
      const length = userComment.comments.length;
      for(let j=0; j < length; j++){
        if(foundComments[i] == userComment.comments[j]){
          userComment.comments.splice(j,1);
          await userComment.save();
        }
      }
    }

    await db.Post.findByIdAndDelete(req.params.id);
    res.redirect("/");
  } catch (error) {
    req.flash('error', error);
    return res.redirect("404");                                                          // redirect to 404 Page if there is an error
  }
});


// upvote route
router.get("/:id/up", async (req, res) => {
  try {
    const foundPost = await db.Post.findById(req.params.id);
    const foundUser = await db.User.findById(foundPost.user);

    for(let i = 0; i < foundPost.downvotes.length; i++){
      if(req.session.currentUser.id == foundPost.downvotes[i]){
        foundPost.downvotes.splice(i,1);
        await foundPost.save();
        foundUser.karma++;
        await foundUser.save();
      }
    }
    foundPost.upvotes.push(req.session.currentUser.id);
    await foundPost.save();

    foundUser.karma++;
    await foundUser.save();

    const totalVotes = foundPost.upvotes.length - foundPost.downvotes.length;
    foundPost.votes = totalVotes;
    await foundPost.save();

    res.json(foundPost);
  } catch (error) {
      console.log(error)
      req.flash('error', error);
    return res.redirect("404");                                                          // redirect to 404 Page if there is an error
  }
});

// downvote route
router.get("/:id/down", async (req, res) => {
  try {
    const foundPost = await db.Post.findById(req.params.id);
    const foundUser = await db.User.findById(foundPost.user);

    for(let i = 0; i < foundPost.upvotes.length; i++){
      if(req.session.currentUser.id == foundPost.upvotes[i]){
        foundPost.upvotes.splice(i,1);
        await foundPost.save();
        foundUser.karma--;
        await foundUser.save();
      }
    }
    foundPost.downvotes.push(req.session.currentUser.id);
    await foundPost.save();

    foundUser.karma--;
    await foundUser.save();

    const totalVotes = foundPost.upvotes.length - foundPost.downvotes.length;
    foundPost.votes = totalVotes;
    await foundPost.save();

    res.json(foundPost);
  } catch {
    console.log(error)
    req.flash('error', error);
    return res.redirect("404");                                                          // redirect to 404 Page if there is an error
  }

});

// even route
router.get("/:id/even", async (req, res) => {
  try {
    const foundPost = await db.Post.findById(req.params.id);
    const foundUser = await db.User.findById(foundPost.user);


    for(let i = 0; i < foundPost.upvotes.length; i++){
      if(req.session.currentUser.id == foundPost.upvotes[i]){
        foundPost.upvotes.splice(i,1);
        await foundPost.save();
        foundUser.karma--;
        await foundUser.save();
      }
    }
    for(let i = 0; i < foundPost.downvotes.length; i++){
      if(req.session.currentUser.id == foundPost.downvotes[i]){
        foundPost.downvotes.splice(i,1);
        await foundPost.save();
        foundUser.karma++;
        await foundUser.save();
      }
    }

    const totalVotes = foundPost.upvotes.length - foundPost.downvotes.length;
    foundPost.votes = totalVotes;
    await foundPost.save();

    res.json(foundPost);
  } catch {
    console.log(error)
    req.flash('error', error);
    return res.redirect("404");                                                          // redirect to 404 Page if there is an error
  }

});
/*
var testdata = [
  {
    title: "titleTest",
    title2: "titleTest2",
    uniqueNum: 9000009,
    client: "ClientAAAA",
    contactName: "NameA",
    contactEmail: "ContEmailA",
    contactNumber: "09876",
    body: "aaaaaaaaaaaaaa",
    votes: 0,
    startmonth: "jan",
    startday: "2",
    starttime: "20:40",
    endmonth: "jan",
    endday: "2",
    endtime: "21:40",
    cecoevent: "Rugby", //subreddit
    username: "Theuns",
    category: "Rugby",
    group: "Group",
    EntityToRent: "NoneEntityTest",
    chargePeriod:  "Charge per Hour",
    PeriodsRequired: "1",
    strike: "01:00",
    NumberRequired: "3",
    CostPerHour: "20"
  },
  {
    timestamps: true,
    createdAt: "publishedAt",
  } // going to add createdAt, updatedAt
  ,
  {
    title: "titleTestBBBBB",
    title2: "titleTest2BBBBB",
    uniqueNum: 9000009,
    client: "ClientBBBBB",
    contactName: "NameBBBBB",
    contactEmail: "ContEmailBBBBB",
    contactNumber: "09876",
    body: "aaaaaaaaaaaaaaBBBBB",
    votes: 0,
    startmonth: "janBBBBB",
    startday: "2",
    starttime: "20:40",
    endmonth: "janBBBBB",
    endday: "2",
    endtime: "21:40",
    cecoevent: "Rugby", //subreddit
    username: "Theuns",
    category: "Rugby",
    group: "Group",
    EntityToRent: "NoneEntityTestBBBBB",
    chargePeriod:  "Charge per HourBBBBB",
    PeriodsRequired: "1",
    strike: "01:00",
    NumberRequired: "3",
    CostPerHour: "20"
  },
  {
    timestamps: true,
    createdAt: "publishedAtBBBBB",
  } // going to add createdAt, updatedAt
];

var testdata2 = '{title:"titleTest",title2:"titleTest2",uniqueNum:9000009,client:"ClientAAAA",contactName:"NameA",contactEmail:"ContEmailA",contactNumber:"09876",body: "aaaaaaaaaaaaaa",votes:0,startmonth:"jan",startday:"2",starttime:"20:40",endmonth:"jan",endday:"2",endtime:"21:40",cecoevent:"Rugby",username:"Theuns",category:"Rugby",group:"Group",EntityToRent:"NoneEntityTest",chargePeriod:"Charge per Hour",PeriodsRequired:"1",strike:"01:00",NumberRequired:"3",CostPerHour:"20"},{timestamps:true,createdAt:"publishedAt"}' ;*/
module.exports = router;
