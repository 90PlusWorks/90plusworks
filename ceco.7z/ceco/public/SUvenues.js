var venues = `Faculty,Building,-Room,Squaremeters,Ratepersquaremeter,Ratefortheyear,Hourswithinayear,Rateperhour
SU_Personnel,Unspecified,at R70/h,NA,NA,NA,NA,75
SU_Personnel,Unspecified,at R100/h,NA,NA,NA,NA,100
SU_Personnel,Unspecified,at R150/h,NA,NA,NA,NA,150
SU_Personnel,Unspecified,at R200/h,NA,NA,NA,NA,200
SU_Personnel,Unspecified,Usher at R70/h,NA,NA,NA,NA,70
SU_Personnel,Unspecified,General Labour/Venue Prep at R70/h,NA,NA,NA,NA,70
SU_Personnel,Unspecified,Access Control at R70/h,NA,NA,NA,NA,70
SU_Personnel,Stage Events,Stage Hand at R70/h,NA,NA,NA,NA,70
SU_Personnel,Stage Events,Assistant Lighting Technician at R100/h,NA,NA,NA,NA,100
SU_Personnel,Stage Events,Bar Staff at R100/h,NA,NA,NA,NA,100
SU_Personnel,Stage Events,Ticket Sales Staff at R100/h,NA,NA,NA,NA,100
SU_Personnel,Stage Events,Dressers at R100/h,NA,NA,NA,NA,100
SU_Personnel,Stage Events,Fly Operator at R100/h,NA,NA,NA,NA,100
SU_Personnel,Stage Events,Technician on Duty at R200/h,NA,NA,NA,NA,200
SU_Personnel,Stage Events,Venue Manager at R200/h,NA,NA,NA,NA,200
SU_Personnel,Stage Events,IT Technician at R200/h,NA,NA,NA,NA,200
SU_Personnel,Stage Events,Sound Technician at R100/h,NA,NA,NA,NA,100
SU_Personnel,Stage Events,Sound Technician at R150/h,NA,NA,NA,NA,150
SU_Personnel,Stage Events,Sound Technician at R200/h,NA,NA,NA,NA,200
SU_Personnel,Stage Events,Stage Manager at R100/h,NA,NA,NA,NA,100
SU_Personnel,Stage Events,Stage Manager at R150/h,NA,NA,NA,NA,150
SU_Personnel,Stage Events,Stage Manager at R200/h,NA,NA,NA,NA,200
SU_Personnel,Stage Events,FOH Manager at R150/h,NA,NA,NA,NA,150
SU_Personnel,Stage Events,FOH Manager at R200/h,NA,NA,NA,NA,200
SU_Personnel,Stage Events,Lighting Technician at R150/h,NA,NA,NA,NA,150
SU_Personnel,Stage Events,Lighting Technician at R200/h,NA,NA,NA,NA,200
SU_Personnel,Stage Events,Crew: Professional (AS SU Staff) at R100/h,NA,NA,NA,NA,100
SU_Personnel,Stage Events,Crew: Professional (AS SU Staff) at R150/h,NA,NA,NA,NA,150
SU_Personnel,Stage Events,Crew: Professional (AS SU Staff) at R200/h,NA,NA,NA,NA,200
SU_Personnel,Stage Events,Crew: Student at R70/h,NA,NA,NA,NA,70
SU_Personnel,Stage Events,Setup/Brand Assistance Staff at R70/h,NA,NA,NA,NA,70
SU_Personnel,Stage Events,Event Assistant at R200/h,NA,NA,NA,NA,200
Rental_Items,Tables and Table Cloths,Black frame cocktail tables with wood top (8 available at R300 each),NA,NA,NA,NA,300
Rental_Items,Tables and Table Cloths,White foldable trestle tables (5 available at R100 each),NA,NA,NA,NA,100
Rental_Items,Tables and Table Cloths,Black Table Cloths(8  R70 each),NA,NA,NA,NA,70
Rental_Items,Electronics: Tablets-PA(Speaker)-Printers,JBL Bluetooth Portable PA system (Speaker_MIC_Stand_Cable),NA,NA,NA,NA,800  
Rental_Items,Electronics: Tablets-PA(Speaker)-Printers,CECO Samsung Tablets for registration and ticket scanning (2 available at R300 each),NA,NA,NA,NA,300
Rental_Items,Electronics: Tablets-PA(Speaker)-Printers,Pantum Printers for Onsite registration badges (4 available at R300 each),NA,NA,NA,NA,300
Rental_Items,General Accessories,Flip Chart Unit excluding paper (1 available at R200),NA,NA,NA,NA,200
Rental_Items,General Accessories,Black Stanchion Ropes (6 available at R30 each),NA,NA,NA,NA,30
Rental_Items,General Accessories,Gold Stanction Poles (8 available at R80 each),NA,NA,NA,NA,80
Rental_Items,General Accessories,Silver Champagne Cooler (1 available at R65),NA,NA,NA,NA,65
Rental_Items,General Accessories,SU Branded Pull up Banners (8 available at R200),NA,NA,NA,NA,200
Rental_Items,General Accessories,Lollipop Stands for registration and directional signage (4 available at R50),NA,NA,NA,NA,50
Agri_Sciences,De_Beers_Building_Chemistry,BC-26-Room-2003(LectureHall),156.92,2151.08,337550.55,8760,38.53
Agri_Sciences,Die_Stalle,BC-913-Room-2002(Committee-Room),27.66,2151.08,59502.19,8760,6.79
Agri_Sciences,Food_Science,BC-146-Room-4001(Seminar-Room),49.3,2151.08,106041.3,8760,12.11
Agri_Sciences,Food_Science,BC-146-Room-4002(Kitchen),11.69,2151.08,25135.55,8760,2.87
Agri_Sciences,Food_Science,BC-146-Room-3001(SittingArea),26.15,2151.08,56251.81,8760,6.42
Agri_Sciences,Food_Science,BC-146-Room-3002(SittingArea),30.41,2151.08,65404.83,8760,7.47
Agri_Sciences,Food_Science,BC-146-Room-2007(SittingArea),45.66,2151.08,98227.75,8760,11.21
Agri_Sciences,Food_Science,BC-146-Room-1002(LectureHall),77.59,2151.08,166901.99,8760,19.05
Agri_Sciences,Food_Science,BC-146-Room-4008(LectureHall),154.47,2151.08,332283.16,8760,37.93
Agri_Sciences,Food_Science,BC-146-Room-4006(Committee-Room),17.18,2151.08,36960.94,8760,4.22
Agri_Sciences,JH_Neethling,BC-113-Room-1003(LectureHall),95.96,2151.08,206423.07,8760,23.56
Agri_Sciences,JH_Neethling,BC-113-Room-1027(LectureHall),101.02,2151.08,217312.49,8760,24.81
Agri_Sciences,JS_Marais,BC-64-Room-1017-C(Seminar-Room),39.48,2151.08,84915.22,8760,9.69
Agri_Sciences,JS-Marais,BC-64-Room-3028(LectureHall),187.28,2151.08,402860.81,8760,45.99
Agri_Sciences,JS_Marais,BC-64-Room-1035(LectureHall),49.16,2151.08,105751.56,8760,12.07
Agri_Sciences,JS_Marais,BC-64-Room-1002(LectureHall),271.38,2151.08,583757.56,8760,66.64
Agri_Sciences,Lombardi_Building,BC-101-Room-3001(LectureHall),133.54,2151.08,287248.32,8760,32.79
Agri_Sciences,Lombardi_Building,BC-101-Room-2001(Laboratory-Teaching),156.63,2151.08,336932.8,8760,38.46
Agri_Sciences,Lombardi_Building,BC-101-Room-2007(Seminar-Room),64.28,2151.08,138269.67,8760,15.78
Agri_Sciences,PO_Sauer,BC-10-Room-1006(LectureHall),182.25,2151.08,392032.81,8760,44.75
Agri_Sciences,PO_Sauer,BC-10-Room-1008(LectureHall),28.17,2151.08,60593.31,8760,6.92
Agri_Sciences,PO_Sauer,BC-10-Room-1051(LectureHall),59.36,2151.08,127681.58,8760,14.58
Agri_Sciences,PO_Sauer,BC-10-Room-1052(LectureHall),59.36,2151.08,127681.58,8760,14.58
Agri_Sciences,PO_Sauer,BC-10-Room-1053(LectureHall),59.35,2151.08,127677.33,8760,14.58
Agri_Sciences,Welgevallen_WineCellar,BC-744-Room-105(FermentationCellar),171.38,2151.08,368644.05,8760,42.08
Agri_Sciences,Welgevallen_WineCellar,BC-744-Room-104(WineSales),34.91,2151.08,75092.42,8760,8.57
Agri_Sciences,Welgevallen_WineCellar,BC-744-Room-100(CrushingCellar),70.19,2151.08,150983.39,8760,17.24
Arts_and_Social_Sciences,Adam_Small_Theatre_Complex,Kitchen2ndFloorFoyerSpecEquip,NA,2589.76,NA,8760,GetAvgate/SQM
Arts_and_Social_Sciences,Adam_Small_Theatre_Complex,NA,NA,2589.76,NA,8760,GetAvgate/SQM
Arts_and_Social_Sciences,Adam_Small_Theatre_Complex,Auditorium,1061.74,2589.76,2749657.75,8760,526.03
Arts_and_Social_Sciences,Adam_Small_Theatre_Complex,AuditoriumincludingFoyer,1602.84,2589.76,4150979.78,8760,696.23
Arts_and_Social_Sciences,Adam_Small_Theatre_Complex,Foyer,541.1,2589.76,1401322.03,8760,170.19
Arts_and_Social_Sciences,Adam_Small_Theatre_Complex,FoyerOffice1040,17.94,2589.76,46451.83,8760,5.30
Arts_and_Social_Sciences,Adam_Small_Theatre_Complex,Laboratory,294.5,2589.76,762674.84,8760,102.66
Arts_and_Social_Sciences,Adam_Small_Theatre_Complex,TVandSoundStudio,211.83,2589.76,548577.61,8760,65.04
Arts_and_Social_Sciences,Adam_Small_Theatre_Complex,TUT-Room2034,32.96,2589.76,85350.42,8760,9.74
Arts_and_Social_Sciences,Adam_Small_Theatre_Complex,Seminar-Room1013,26.6,2589.76,68876.18,8760,7.86
Arts_and_Social_Sciences,Adam_Small_Theatre_Complex,Seminar-Room2032,92.06,2589.76,238407.62,8760,37.98
Arts_and_Social_Sciences,Adam_Small_Theatre_Complex,Workshop1029,79.12,2589.76,204896.68,8760,23.39
Arts_and_Social_Sciences,Adam_Small_Theatre_Complex,Rehearsal-Room1010,78.66,2589.76,203719.31,8760,23.54
Arts_and_Social_Sciences,Adam_Small_Theatre_Complex,Bar1038Level1,18.07,2589.76,46788.69,8760,5.34
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-201(LectureHall),28.92,2589.76,74896.36,8760,8.55
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-202(LectureHall),28.9,2589.76,74831.55,8760,8.54
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-203(LectureHall),29.04,2589.76,75215.93,8760,8.59
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-204(LectureHall),28.75,2589.76,74448.32,8760,8.50
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-205(LectureHall),41.52,2589.76,107535.44,8760,12.28
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-206(LectureHall),28.76,2589.76,74494.22,8760,8.50
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-208(LectureHall),41.55,2589.76,107595.21,8760,12.28
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-209(LectureHall),40.88,2589.76,105864.07,8760,12.08
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-212(LectureHall),41.28,2589.76,106914.92,8760,12.20
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-213(LectureHall),41.63,2589.76,107808.02,8760,12.31
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-216(LectureHall),41.22,2589.76,106754.01,8760,12.19
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-217(LectureHall),19.93,2589.76,51604.89,8760,5.89
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-219(LectureHall),20.2,2589.76,52303.39,8760,5.97
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-220(LectureHall),61.81,2589.76,160079.88,8760,18.27
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-221(LectureHall),67.43,2589.76,174635.36,8760,19.94
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-228(LectureHall),63.11,2589.76,163449.26,8760,18.66
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-229(LectureHall),116.07,2589.76,300586.79,8760,34.31
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-227(LectureHall),115.99,2589.76,300396.65,8760,34.29
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-225(LectureHall),115.99,2589.76,300389.43,8760,34.29
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-223(LectureHall),114.77,2589.76,297230.1,8760,33.93
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-222(LectureHall),70.38,2589.76,182261.81,8760,20.81
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-224(LectureHall),72.07,2589.76,186651.91,8760,21.31
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-226(LectureHall),72.08,2589.76,186660.5,8760,21.31
Arts_and_Social_Sciences,Arts_and_Social_Sciences_Building,BC-84-Room-230(LectureHall),348.12,2589.76,901555.75,8760,102.92
Arts_and_Social_Sciences,Conservatory_for_Music,0,NA,2589.76,NA,8760,GetAvgate/SQM
Arts_and_Social_Sciences,Conservatory_for_Music,-Room/HallDescription,ActualSqmusedbyCECOperrental,2589.76,NA,8760,NA
Arts_and_Social_Sciences,Conservatory_for_Music,EndlerHallincluding1stand2ndFloorFoyers,1203.25,2589.76,3116132.42,8760,525.06
Arts_and_Social_Sciences,Conservatory_for_Music,EndlerHall,618.05,2589.76,1600602.52,8760,345.35
Arts_and_Social_Sciences,Conservatory_for_Music,FismerHallincluding1stFloorFoyer,533.82,2589.76,1382475.1,8760,247.32
Arts_and_Social_Sciences,Conservatory_for_Music,FismerHall,276.12,2589.76,715091.79,8760,164.43
Arts_and_Social_Sciences,Conservatory_for_Music,JannaschHallincluding1stFloorFoyer,474.08,2589.76,1227757.46,8760,194.28
Arts_and_Social_Sciences,Conservatory_for_Music,JannaschHall,216.38,2589.76,560374.15,8760,111.39
Arts_and_Social_Sciences,Conservatory_for_Music,Foyer1stFloor,257.7,2589.76,667383.32,8760,82.89
Arts_and_Social_Sciences,Conservatory_for_Music,Foyer2ndFloor,327.5,2589.76,848146.58,8760,96.82
Arts_and_Social_Sciences,Conservatory_for_Music,FismerKitchenA202,12.62,2589.76,32671.42,8760,3.73
Arts_and_Social_Sciences,Conservatory_for_Music,SoundControlD203,15.77,2589.76,40845.25,8760,4.66
Arts_and_Social_Sciences,Conservatory_for_Music,TVControlD204,15.49,2589.76,40119.54,8760,4.58
Arts_and_Social_Sciences,Conservatory_for_Music,SoundControlA206,19.99,2589.76,51774.1,8760,43.16
Arts_and_Social_Sciences,Conservatory_for_Music,RecordingStudioA205,16.62,2589.76,43045.76,8760,4.91
Arts_and_Social_Sciences,Conservatory_for_Music,RecordingStudioA208,49.47,2589.76,128124.31,8760,14.63
Arts_and_Social_Sciences,Conservatory_for_Music,RecordingStudioA212,63.17,2589.76,163587.84,8760,18.67
Arts_and_Social_Sciences,Conservatory_for_Music,RecordingStudioA213,104.94,2589.76,271769.22,8760,31.02
Arts_and_Social_Sciences,Conservatory_for_Music,SubmarineRecordingA211,39.52,2589.76,102346.16,8760,48.93
Arts_and_Social_Sciences,Conservatory_for_Music,Staff-RoomA201,77.23,2589.76,200003.35,8760,22.83
Arts_and_Social_Sciences,Conservatory_for_Music,Lecture-RoomA214,87.63,2589.76,226941.77,8760,25.91
Arts_and_Social_Sciences,Conservatory_for_Music,Lecture-RoomA221,71.7,2589.76,185678.97,8760,21.20
Arts_and_Social_Sciences,Conservatory_for_Music,LectureHallA135,71.99,2589.76,186445.98,8760,21.28
Arts_and_Social_Sciences,Conservatory_for_Music,StudioC101,50.91,2589.76,131851.04,8760,15.05
Arts_and_Social_Sciences,Conservatory_for_Music,StudioC201,50.91,2589.76,131851.6,8760,15.05
Arts_and_Social_Sciences,Conservatory_for_Music,StudioD213,42.06,2589.76,108934.48,8760,12.44
Arts_and_Social_Sciences,Conservatory_for_Music,Seminar-RoomB112,20.89,2589.76,54102.79,8760,6.18
Arts_and_Social_Sciences,Conservatory_for_Music,PianoPractice-RoomC111-C123,10.33,2589.76,26740.71,8760,3.05
Arts_and_Social_Sciences,Conservatory_for_Music,PianoPractice-RoomC211-C223,10.32,2589.76,26738.53,8760,3.05
Arts_and_Social_Sciences,Conservatory_for_Music,OrganPractice-RoomC124-C129,16.19,2589.76,41933.93,8760,4.79
Arts_and_Social_Sciences,Conservatory_for_Music,OrganPractice-RoomC224-C229,16.19,2589.76,41933.56,8760,4.79
Arts_and_Social_Sciences,Conservatory_for_Music,RehearsalPractice-RoomC311-C323(Small),10.32,2589.76,26739.05,8760,3.05
Arts_and_Social_Sciences,Conservatory_for_Music,RehearsalPractice-RoomC324-C329(Large),16.19,2589.76,41931.48,8760,4.79
Arts_and_Social_Sciences,Conservatory_for_Music,Listening-RoomB111(Small),23.94,2589.76,62002.17,8760,7.08
Arts_and_Social_Sciences,Conservatory_for_Music,Listening-RoomB113(Large),76.94,2589.76,199266.98,8760,22.75
Arts_and_Social_Sciences,Conservatory_for_Music,CoffeeShopD105,26.26,2589.76,68018.66,8760,7.76
Arts_and_Social_Sciences,GUS,BC-18-Room-104(Exhibitionarea(betweenChapelandProjection-Room)),51.91,2589.76,134431.35,8760,15.35
Arts_and_Social_Sciences,GUS,BC-18-Room-105(Projection-Room),96.57,2589.76,250088.68,8760,28.55
Arts_and_Social_Sciences,GUS,BC-18-Room-101(Chapel),115.82,2589.76,299954.32,8760,34.24
Arts_and_Social_Sciences,Journalism,BC-817-Room-1011(LectureHall),80.54,2589.76,208577.59,8760,23.81
Arts_and_Social_Sciences,Krotoa_Building,BC-127-Room-3002(Honours-Room),122.27,2589.76,316660.21,8760,36.15
Arts_and_Social_Sciences,Krotoa_Building,BC-127-Room-4045(LectureVenue),102.17,2589.76,264608.09,8760,30.21
Arts_and_Social_Sciences,Krotoa_Building,BC-127-Room-4043(LectureVenue),102.33,2589.76,265018.52,8760,30.25
Arts_and_Social_Sciences,Krotoa_Building,BC-127-Room-3001(LectureHall),269.96,2589.76,699120.71,8760,79.81
Arts_and_Social_Sciences,Krotoa_Building,BC-127-Room-1001(LectureVenue),272.89,2589.76,706731.01,8760,80.68
Arts_and_Social_Sciences,Krotoa_Building,BC-127-Room-1012(LectureHall),165.49,2589.76,428585.64,8760,48.93
Arts_and_Social_Sciences,Visual_Arts,BC-112-Room-1003-A(-Room-Aquatint),2.39,2589.76,6200.05,8760,0.71
Arts_and_Social_Sciences,Visual_Arts,BC-112-Room-1003(EtchingStudio),64.46,2589.76,166934.91,8760,19.06
Arts_and_Social_Sciences,Visual_Arts,BC-112-Room-1008(Studio),56.83,2589.76,147186.48,8760,16.80
Arts_and_Social_Sciences,Visual_Arts,BC-112-Room-1032(Workshop),96.77,2589.76,250616.67,8760,28.61
Arts_and_Social_Sciences,Visual_Arts,BC-112-Room-1021(Studio),62.5,2589.76,161849.88,8760,18.48
Arts_and_Social_Sciences,Visual_Arts,BC-112-Room-1015(JewelleryDesign),69.48,2589.76,179937.06,8760,20.54
Arts_and_Social_Sciences,Visual_Arts,BC-112-Room-1023-A(Dark-Room),6.7,2589.76,17346.72,8760,1.98
Arts_and_Social_Sciences,Visual_Arts,BC-112-Room-1000(Foyer),236.84,2589.76,613366.74,8760,70.02
Arts_and_Social_Sciences,Visual_Arts,BC-112-Room-3001(Chapel),83.5,2589.76,216243.57,8760,24.69
Arts_and_Social_Sciences,Visual_Arts,BC-112-Room-2002(Studio),110.82,2589.76,287002.86,8760,32.76
Arts_and_Social_Sciences,Visual_Arts,BC-112-Room-2003(Studio),227.04,2589.76,587989.08,8760,67.12
Arts_and_Social_Sciences,Visual_Arts,BC-112-Room-2012(Seminar-Room),46.6,2589.76,120691.62,8760,13.78
Arts_and_Social_Sciences,Visual_Arts,BC-112-Room-1024(LectureHall),166,2589.76,429890.14,8760,49.07
Economic_and_Management_Sciences,Africa_Centre_for_HIV_and_AIDS_Management,BC-116-Room-2001(Committee-Room),62.45,3998.74,249706.93,8760,28.51
Economic_and_Management_Sciences,Africa_Centre_for_HIV_and_AIDS_Management,BC-116-Room-1012(Drama-Room),53.88,3998.74,215440.84,8760,24.59
Economic_and_Management_Sciences,Africa_Centre_for_HIV_and_AIDS_Management,BC-116-Room-1005(Committee-Room),12.13,3998.74,48507.39,8760,5.54
Economic_and_Management_Sciences,Africa_Centre_for_HIV_and_AIDS_Management,BC-116-Room-2014(Committee-Room),135.33,3998.74,541133.74,8760,61.77
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-122(Winery),168.98,3998.74,675704.95,8760,77.14
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-1001-A(Corridor),6.34,3998.74,25366.21,8760,2.90
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-2059(Honeybush),117.29,3998.74,469012.27,8760,53.54
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-2058(Protea),117.85,3998.74,471252.1,8760,53.80
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-206(Red-Room),19.13,3998.74,76489.97,8760,8.73
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-204(Green-Room),18.19,3998.74,72742.52,8760,8.30
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-212(Marula),112.54,3998.74,450030.31,8760,51.37
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-216(Baobab),132.42,3998.74,529529.24,8760,60.45
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-332(Innovation),45.01,3998.74,179982.04,8760,20.55
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-333(Vision),98.83,3998.74,395203.04,8760,45.11
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-2073(Orange-Room),11.73,3998.74,46895.99,8760,5.35
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-2074(Yellow-Room),11.58,3998.74,46305.54,8760,5.29
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-2075(Navy-Room),11.61,3998.74,46428.24,8760,5.30
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-2076(Purple-Room),11.72,3998.74,46870.85,8760,5.35
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-2072(Mopani),140.51,3998.74,561863.47,8760,64.14
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-271(Library),363.59,3998.74,1453884.47,8760,165.97
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-1001(Restaurant),404.03,3998.74,1615603.62,8760,184.43
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-279(Fynbos),102.86,3998.74,411304.35,8760,46.95
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-277(Rooibos),111.37,3998.74,445340.59,8760,50.84
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-253(OpenPlanArea),8.19,3998.74,32735.99,8760,3.74
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-210(Yellowwood),203.75,3998.74,814729.29,8760,93.01
Economic_and_Management_Sciences,Belville_Park_Campus,BC-650-Room-1008(SeparateDinningarea(Restaurant)),79.01,3998.74,315937.31,8760,36.07
Economic_and_Management_Sciences,CGW_Schumann,BC-49-Room-101(LectureHall),135.74,3998.74,542770.83,8760,61.96
Economic_and_Management_Sciences,CGW_Schumann,BC-49-Room-104(LectureHall),233.83,3998.74,935036.72,8760,106.74
Economic_and_Management_Sciences,CGW_Schumann,BC-49-Room-107(LectureHall),135.72,3998.74,542689.19,8760,61.95
Economic_and_Management_Sciences,CGW_Schumann,BC-49-Room-237(LectureHall),51.66,3998.74,206560.98,8760,23.58
Economic_and_Management_Sciences,CGW_Schumann,BC-49-Room-211(Meeting-Room),9.43,3998.74,37707.81,8760,4.30
Economic_and_Management_Sciences,CGW_Schumann,BC-49-Room-201(Lobby),10.29,3998.74,41164.76,8760,4.70
Economic_and_Management_Sciences,CGW_Schumann,BC-49-Room-225(LectureHall),103.85,3998.74,415257.29,8760,47.40
Economic_and_Management_Sciences,CGW_Schumann,BC-49-Room-230(LectureHall),101.59,3998.74,406234.25,8760,46.37
Economic_and_Management_Sciences,CGW_Schumann,BC-49-Room-221(LectureHall),90.9,3998.74,363467.46,8760,41.49
Economic_and_Management_Sciences,CGW_Schumann,BC-49-Room-234(Meeting-Room),23.27,3998.74,93040.12,8760,10.62
Economic_and_Management_Sciences,CGW_Schumann,BC-49-Room-229(LectureHall),79.17,3998.74,316582.7,8760,36.14
Economic_and_Management_Sciences,Mathematical_Sciences_and_Industrial_Psychology,BC-114-Room-2002(LectureHall),111.18,3998.74,444569.47,8760,50.75
Economic_and_Management_Sciences,Mathematical_Sciences_and_Industrial_Psychology,BC-114-Room-1005(LectureHall),291.52,3998.74,1165704.65,8760,133.07
Economic_and_Management_Sciences,Mathematical_Sciences_and_Industrial_Psychology,BC-114-Room-3001(LectureHall),205.6,3998.74,822153.03,8760,93.85
Economic_and_Management_Sciences,Van_Der_Horst,BC-660-Room-113(LectureHall),136.88,3998.74,547330.06,8760,62.48
Economic_and_Management_Sciences,Van_Der_Horst,BC-660-Room-103(LectureHall),61.05,3998.74,244139.19,8760,27.87
Economic_and_Management_Sciences,Van_Der_Horst,BC-660-Room-107(LectureHall),41.1,3998.74,164342.68,8760,18.76
Economic_and_Management_Sciences,Van_Der_Horst,BC-660-Room-105(LectureHall),87.04,3998.74,348040.08,8760,39.73
Economic_and_Management_Sciences,Van_Der_Horst,BC-660-Room-102(Auditorium),132.7,3998.74,530650.8,8760,60.58
Economic_and_Management_Sciences,Van_Der_Horst,BC-660-Room-101(Auditorium),148.58,3998.74,594149.11,8760,67.83
Economic_and_Management_Sciences,Van_Der_Horst,BC-660-Room-201(LectureHall),61.05,3998.74,244139.19,8760,27.87
Economic_and_Management_Sciences,Van_Der_Horst,BC-660-Room-205(LectureHall),86.84,3998.74,347232.71,8760,39.64
Economic_and_Management_Sciences,Van_Der_Horst,BC-660-Room-114(vandenHorstCafeteria),216.79,3998.74,866877.4,8760,98.96
Economic_and_Management_Sciences,Van_Der_Sterr_Building,BC-144-Room-1003(LectureHall),113.64,3998.74,454415.7,8760,51.87
Economic_and_Management_Sciences,Van_Der_Sterr_Building,BC-144-Room-1032(LectureHall),155.81,3998.74,623024.18,8760,71.12
Economic_and_Management_Sciences,Van_Der_Sterr_Building,BC-144-Room-2118(LectureHall),91.85,3998.74,367283.92,8760,41.93
Economic_and_Management_Sciences,Van_Der_Sterr_Building,BC-144-Room-1033(LectureHall),111.96,3998.74,447709.79,8760,51.11
Economic_and_Management_Sciences,Van_Der_Sterr_Building,BC-144-Room-1046(LectureHall),204.14,3998.74,816320.61,8760,93.19
Economic_and_Management_Sciences,Van_Der_Sterr_Building,BC-144-Room-3124(LectureHall),279.8,3998.74,1118866.39,8760,127.72
Economic_and_Management_Sciences,Van_Der_Sterr_Building,BC-144-Room-2121(LectureHall),279.81,3998.74,1118874.59,8760,127.73
Economic_and_Management_Sciences,Van_Der_Sterr_Building,BC-144-Room-1004(LectureHall),96.6,3998.74,386285.61,8760,44.10
Economic_and_Management_Sciences,Van_Der_Sterr_Building,BC-144-Room-1041(Seminar-Room),120.39,3998.74,481398.06,8760,54.95
Economic_and_Management_Sciences,Van_Der_Sterr_Building,BC-144-Room-1042(Reception-Room),82.68,3998.74,330626.28,8760,37.74
Economic_and_Management_Sciences,Van_Der_Sterr_Building,BC-144-Room-1043(Kitchen),11.75,3998.74,47001.62,8760,5.37
Education,Education_Building,BC-92-Room-1106(LectureHall),387.98,3201.39,1242068.93,8760,141.79
Education,Education_Building,BC-92-Room-3041(Computer-Room),180.6,3201.39,578179.24,8760,66.00
Education,Education_Building,BC-92-Room-1034(LectureHall),237.76,3201.39,761148.64,8760,86.89
Education,Education_Building,BC-92-Room-1018(Lecture-Room-OccupationalTherapy),113.77,3201.39,364206.44,8760,41.58
Education,Education_Building,BC-92-Room-1080(LectureHall4),176.4,3201.39,564718.96,8760,64.47
Education,Education_Building,BC-92-Room-1093(LectureHall2),114.29,3201.39,365871.68,8760,41.77
Education,Education_Building,BC-92-Room-1083(LectureHall3),143.27,3201.39,458655.41,8760,52.36
Education,Education_Building,BC-92-Room-1048(LectureHall8),176.46,3201.39,564904.69,8760,64.49
Education,Education_Building,BC-92-Room-1050(LectureHall7),290.36,3201.39,929541.85,8760,106.11
Education,Education_Building,BC-92-Room-1097(LectureHall1),169.95,3201.39,544071.46,8760,62.11
Education,Education_Building,BC-92-Room-1065(LectureHall5),169.99,3201.39,544218.5,8760,62.13
Education,Education_Building,BC-92-Room-1201(Auditorium),455.73,3201.39,1458979.19,8760,166.55
Education,Education_Building,BC-92-Room-1202(Auditorium),455.66,3201.39,1458731.09,8760,166.52
Education,Education_Building,BC-92-Room-4075(LectureHall-Physiontherapy),138.75,3201.39,444206.86,8760,50.71
Education,Education_Building,BC-92-Room-4067(Seminar-Room),60.81,3201.39,194660.43,8760,22.22
Education,Education_Building,BC-92-Room-4053-D(Audio-visual),85.48,3201.39,273668.12,8760,31.24
Education,Education_Building,BC-92-Room-4053-B(Seminar-Room),88.23,3201.39,282452.81,8760,32.24
Education,Education_Building,BC-92-Room-4053-A(Seminar-Room),85.14,3201.39,272569.74,8760,31.12
Education,Education_Building,BC-92-Room-4083(Seminar-Room),30.87,3201.39,98826.51,8760,11.28
Education,Education_Building,BC-92-Room-4053-C(Seminar-Room),40.1,3201.39,128388.42,8760,14.66
Education,Education_Building,BC-92-Room-1112(AOPVenue),79.83,3201.39,255552.82,8760,29.17
Education,Education_Building,BC-92-Room-2005(LectureVenue),58.29,3201.39,186617.56,8760,21.30
Education,Education_Building,BC-92-Room-5014(Seminar-Room),75.07,3201.39,240320.92,8760,27.43
Education,Education_Building,BC-92-Room-5035(Lab-Microscope),238.25,3201.39,762715.09,8760,87.07
Education,Education_Building,BC-92-Room-5034(Preparation),39.64,3201.39,126904.3,8760,14.49
Education,Education_Building,BC-92-Room-5068(ExamVenue),929.58,3201.39,2975940.67,8760,339.72
Education,Education_Building,BC-92-Room-5033(Lab-MicrobiologyVirology),236.75,3201.39,757919.9,8760,86.52
Education,GG_Cillié,BC-47-Room-1037(Observation),21.05,3201.39,67382.14,8760,7.69
Education,GG_Cillié,BC-47-Room-1046(Consultation-Room),19.55,3201.39,62572.42,8760,7.14
Education,GG_Cillié,BC-47-Room-1047(Psychometric),13.26,3201.39,42448.81,8760,4.85
Education,GG_Cillié,BC-47-Room-1050(Assessment-Room),8.36,3201.39,26756.36,8760,3.05
Education,GG_Cillié,BC-47-Room-1048(Consultation-Room),13.1,3201.39,41949.61,8760,4.79
Education,GG_Cillié,BC-47-Room-1049(Assessment-Room),7.7,3201.39,24644.63,8760,2.81
Education,GG_Cillié,BC-47-Room-2042(LectureHall),108.53,3201.39,347456.58,8760,39.66
Education,GG_Cillié,BC-47-Room-2051(LectureHall),75.94,3201.39,243123.5,8760,27.75
Education,GG_Cillié,BC-47-Room-2052(LectureHall),61.11,3201.39,195627.07,8760,22.33
Education,GG_Cillié,BC-47-Room-2004(LectureHall),92.21,3201.39,295186.16,8760,33.70
Education,GG_Cillié,BC-47-Room-1028(LectureHall),277.95,3201.39,889823.85,8760,101.58
Education,GG_Cillié,BC-47-Room-3006(LectureHall),63.59,3201.39,203574.46,8760,23.24
Education,GG_Cillié,BC-47-Room-4029(Hall-MclagnenHall),146.59,3201.39,469302.98,8760,53.57
Education,GG_Cillié,BC-47-Room-4003(LectureVenue),61.06,3201.39,195465.21,8760,22.31
Education,GG_Cillié,BC-47-Room-4005(LectureVenue),76.39,3201.39,244549.38,8760,27.92
Education,GG_Cillié,BC-47-Room-4053(LectureVenue),79.53,3201.39,254618.12,8760,29.07
Education,GG_Cillié,BC-47-Room-3001(LectureHall),234.55,3201.39,750894.5,8760,85.72
Education,GG_Cillié,BC-47-Room-4002(LectureVenue),76.33,3201.39,244374.8,8760,27.90
Education,GG_Cillié,BC-47-Room-4054(LectureVenue),81.38,3201.39,260522.84,8760,29.74
Education,GG_Cillié,BC-47-Room-4006(LectureVenue),76.4,3201.39,244576.65,8760,27.92
Education,Sport_Science,BC-87-Room-1001(ExerciseCourt),133.37,3201.39,426961.12,8760,48.74
Education,Sport_Science,BC-87-Room-123(Changing-Room),267.41,3201.39,856084.34,8760,97.73
Education,Sport_Science,BC-87-Room-127(Changing-Room),248.28,3201.39,794847.82,8760,90.74
Education,Sport_Science,BC-87-Room-1014(GymnasticsHall),604.35,3201.39,1934762.2,8760,220.86
Education,Sport_Science,BC-87-Room-106(LectureHallD),82,3201.39,262497.8,8760,29.97
Education,Sport_Science,BC-87-Room-109(LectureHallE),94.15,3201.39,301425.95,8760,34.41
Education,Sport_Science,BC-87-Room-205(SwimmingPool),317.95,3201.39,1017869.62,8760,116.20
Education,Sport_Science,BC-87-Room-208(SwimmingPool),724.46,3201.39,2319272.88,8760,264.76
Education,Sport_Science,BC-87-Room-209(DanceHall),359.21,3201.39,1149965.28,8760,131.27
Education,Sport_Science,BC-87-Room-201(LectureHallA),251.81,3201.39,806125.97,8760,92.02
Education,Sport_Science,BC-87-Room-212(GamesHall),482.25,3201.39,1543882.43,8760,176.24
Education,Sport_Science,BC-87-Room-2000(ExerciseCourt),142.19,3201.39,455219.61,8760,51.97
Education,Sport_Science,BC-87-Room-2001(ExerciseCourt),151.69,3201.39,485606.19,8760,55.43
Education,Sport_Science,BC-87-Room-215(SportsHall),604.23,3201.39,1934385.99,8760,220.82
Education,Sport_Science,BC-87-Room-339(Gallery),37.94,3201.39,121476.05,8760,13.87
Education,Sport_Science,BC-87-Room-338(Committee-Room),78.96,3201.39,252785.38,8760,28.86
Education,Sport_Science,BC-87-Room-310(LectureHall),86.89,3201.39,278182.43,8760,31.76
Education,Sport_Science,BC-87-Room-309(LectureHall),86.81,3201.39,277922.05,8760,31.73
Education,Sport_Science,BC-87-Room-3000(ExerciseCourt),160.54,3201.39,513943,8760,58.67
Education,Sport_Science,BC-87-Room-3001(ExerciseCourt),225.18,3201.39,720887.62,8760,82.29
Engineering,Chemical_Engineering,BC-106-Room-100(Lobby),113.35,1964.17,222634.75,8760,25.41
Engineering,Chemical_Engineering,BC-106-Room-124(Lab),86.99,1964.17,170873.07,8760,19.51
Engineering,Chemical_Engineering,BC-106-Room-319(Conference-Room),24.65,1964.17,48426.41,8760,5.53
Engineering,Chemical_Engineering,BC-106-Room-318(Conference-Room),25.11,1964.17,49320.08,8760,5.63
Engineering,Chemical_Engineering,BC-106-Room-300(Lobby),44.68,1964.17,87756.27,8760,10.02
Engineering,Chemical_Engineering,BC-106-Room-202(LectureHall),82.44,1964.17,161920.69,8760,18.48
Engineering,Chemical_Engineering,BC-106-Room-201(LectureHall),68.3,1964.17,134147.07,8760,15.31
Engineering,Civil_Engineering,BC-105-Room-S2114(Meeting-Room),15.58,1964.17,30609.6,8760,3.49
Engineering,Civil_Engineering,BC-105-Room-S2109(Break-AwayArea),43.84,1964.17,86108.51,8760,9.83
Engineering,Civil_Engineering,BC-105-Room-S2001(LectureHall),285.34,1964.17,560463.65,8760,63.98
Engineering,Civil_Engineering,BC-105-Room-S2005(LectureHall),115.52,1964.17,226907.51,8760,25.90
Engineering,Civil_Engineering,BC-105-Room-S2024(LectureHall),328.25,1964.17,644730.39,8760,73.60
Engineering,Civil_Engineering,BC-105-Room-S2016(Meeting-Room),19.1,1964.17,37524.07,8760,4.28
Engineering,Civil_Engineering,BC-105-Room-S2015(Break-Away-Room),19.75,1964.17,38793.18,8760,4.43
Engineering,Civil_Engineering,BC-105-Room-S1018(LectureHall),494.02,1964.17,970340.1,8760,110.77
Engineering,Civil_Engineering,BC-105-Room-S4017(Meeting-Room),23,1964.17,45167.22,8760,5.16
Engineering,Civil_Engineering,BC-105-Room-S4019(Break-AwayArea),12.4,1964.17,24346.75,8760,2.78
Engineering,Civil_Engineering,BC-105-Room-S4025(LectureHall),118.56,1964.17,232875.82,8760,26.58
Engineering,Civil_Engineering,BC-105-Room-S3007(Meeting-Room),15.51,1964.17,30468.39,8760,3.48
Engineering,Civil_Engineering,BC-105-Room-S3010(Break-AwayArea),29.93,1964.17,58787.89,8760,6.71
Engineering,Civil_Engineering,BC-105-Room-S3061(Lecture-Room),283.68,1964.17,557204.98,8760,63.61
Engineering,Civil_Engineering,BC-105-Room-S4035(Break-AwayArea),41.96,1964.17,82422.98,8760,9.41
Engineering,Civil_Engineering,BC-105-Room-S4036(Meeting-Room),17.53,1964.17,34434.13,8760,3.93
Engineering,Civil_Engineering,BC-105-Room-S3027(Family-Room),16.27,1964.17,31948.93,8760,3.65
Engineering,Electrical_and_Electronic_Eng,BC-104-Room-E202(LectureHall),146.24,1964.17,287246.07,8760,32.79
Engineering,Electrical_and_Electronic_Eng,BC-104-Room-E352(LectureHall),235.19,1964.17,461958.08,8760,52.73
Engineering,Electrical&ElectronicEng,BC-104-Room-E354(LectureHall),100.36,1964.17,197118.75,8760,22.50
Engineering,Engineering_Knowledge_Centre,BC-108-Room-K302(LectureHall),318.08,1964.17,624764.47,8760,71.32
Engineering,Engineering_Knowledge_Centre,BC-108-Room-K303(LectureHall),321.87,1964.17,632208.47,8760,72.17
Engineering,General_Engineering,BC-102-Room-A1031(CafeteriaSeating),236.56,1964.17,464650.82,8760,53.04
Engineering,General_Engineering,BC-102-Room-A1032(CafeteriaSeating),38.32,1964.17,75272.12,8760,8.59
Engineering,General_Engineering,BC-102-Room-A305(LectureHall),159.16,1964.17,312620.12,8760,35.69
Engineering,General_Engineering,BC-102-Room-A306(LectureHall),113.52,1964.17,222982.46,8760,25.45
Engineering,General_Engineering,BC-102-Room-A404(LectureHall),89.92,1964.17,176612.88,8760,20.16
Engineering,General_Engineering,BC-102-Room-A406(LectureHall),159.16,1964.17,312616.37,8760,35.69
Engineering,General_Engineering,BC-102-Room-A407(LectureHall),113.52,1964.17,222982.46,8760,25.45
Engineering,General_Engineering,BC-102-Room-A303B(LectureHall),327.84,1964.17,643937.66,8760,73.51
Engineering,General_Engineering,BC-102-Room-A203(LectureHall),264.36,1964.17,519244.37,8760,59.27
Engineering,General_Engineering,BC-102-Room-A204(LectureHall),176.09,1964.17,345877.37,8760,39.48
Engineering,General_Engineering,BC-102-Room-A503B(Tutorial-Room),317.5,1964.17,623630.83,8760,71.19
Engineering,General_Engineering,BC-102-Room-A503A(Tutorial-Room),192.76,1964.17,378621.58,8760,43.22
Engineering,General_Engineering,BC-102-Room-A403B(LectureHall),317.55,1964.17,623726.2,8760,71.20
Engineering,General_Engineering,BC-102-Room-A1001(LectureHall-Reitzsaal),298.39,1964.17,586094.15,8760,66.91
Engineering,General_Engineering,BC-102-Room-A303A(LectureHall),183.76,1964.17,360932.12,8760,41.20
Engineering,General_Engineering,BC-102-Room-A403A(LectureHall),190.68,1964.17,374535.35,8760,42.76
Facility_Management,Coetzenburg_Centre,BC-308-Room-117(Changing-Room),10.18,3998.74,40726.06,8760,4.65
Facility_Management,Coetzenburg_Centre,BC-308-Room-115(FirstAid),7.68,3998.74,30692.54,8760,3.50
Facility_Management,Coetzenburg_Centre,BC-308-Room-123-A(PlayArea),1402.17,3998.74,5606925.52,8760,640.06
Facility_Management,Coetzenburg_Centre,BC-308-Room-223(SittingArea),747.6,3998.74,2989465.6,8760,341.26
Facility_Management,Coetzenburg_Centre,BC-308-Room-105(Changing-Room),NA,3998.74,NA,8760,GetAvgate/SQM
Facility_Management,Coetzenburg_Centre,BC-308-Room-106(Changing-Room),NA,3998.74,NA,8760,GetAvgate/SQM
Facility_Management,Coetzenburg_Centre,BC-308-Room-107(Changing-Room),NA,3998.74,NA,8760,GetAvgate/SQM
Facility_Management,Coetzenburg_Centre,BC-308-Room-108(Changing-Room),NA,3998.74,NA,8760,GetAvgate/SQM
Facility_Management,Jan_Mouton-Learning_Centre,BC-303-Room-1013(Lecture-Room),424.33,3998.74,1696781.79,8760,193.70
Facility_Management,Jan_Mouton-Learning_Centre,BC-303-Room-1020(Lecture-Room),423.41,3998.74,1693110.63,8760,193.28
Facility_Management,Jan_Mouton-Learning_Centre,BC-303-Room-3010(Auditorium),609.71,3998.74,2438073.91,8760,278.32
Facility_Management,Jan_Mouton-Learning_Centre,BC-303-Room-3013(Auditorium),609.49,3998.74,2437182.23,8760,278.22
Facility_Management,Jan_Mouton-Learning_Centre,BC-303-Room-2010(Computor-Room),333.5,3998.74,1333569.3,8760,152.23
Facility_Management,Jan_Mouton-Learning_Centre,BC-303-Room-2011(Computor-Room),334.1,3998.74,1335980.75,8760,152.51
Facility_Management,Jan_Mouton-Learning_Centre,BC-303-Room-2017(Computor-Room),332.7,3998.74,1330381.02,8760,151.87
Facility_Management,Jan_Mouton-Learning_Centre,BC-303-Room-2015(Computor-Room),332.54,3998.74,1329760.77,8760,151.80
Facility_Management,Lentelus_Clubhouse,BC-62-Room-1001(Changing-Room),34.51,3998.74,138000.64,8760,15.75
Facility_Management,Lentelus_Clubhouse,BC-62-Room-1005(Changing-Room),32.97,3998.74,131837.39,8760,15.05
Facility_Management,Lentelus_Clubhouse,BC-62-Room-1003(Changing-Room),34.69,3998.74,138699.33,8760,15.83
Facility_Management,Lentelus_Clubhouse,BC-62-Room-1007(Changing-Room),32.46,3998.74,129804.97,8760,14.82
Facility_Management,Squash_Courts,BC-320-Room-1009(SquashCourt),63.08,3998.74,252238.63,8760,28.79
Facility_Management,Squash_Courts,BC-320-Room-1006(SquashCourt),63.08,3998.74,252240.16,8760,28.79
Facility_Management,Squash_Courts,BC-320-Room-1005(SquashCourt),63.08,3998.74,252238.6,8760,28.79
Facility_Management,Squash_Courts,BC-320-Room-1003(SquashCourt),63.08,3998.74,252245.52,8760,28.80
Facility_Management,Squash_Courts,BC-320-Room-1008(Changing-Room),16.34,3998.74,65338.85,8760,7.46
Facility_Management,Squash_Courts,BC-320-Room-1007(Changing-Room),16,3998.74,63997.35,8760,7.31
Facility_Management,Squash_Courts,BC-320-Room-1002(Changing-Room),9.92,3998.74,39681.4,8760,4.53
Facility_Management,Squash_Courts,BC-320-Room-1004(Changing-Room),22.09,3998.74,88337.61,8760,10.08
Facility_Management,Wilgenhof_Squash_Court,BC-278-Room-1021(SquashCourt),61.52,3998.74,246004.53,8760,28.08
Law,CL_Marais_Library,BC-20-Room-1009(Committee-Room),27.99,4530.97,126821.16,8760,14.48
Law,Old_Main_Building,BC-109-Room-1028-A(Seminar-Room),58.01,4530.97,262826.03,8760,30.00
Law,Old_Main_Building,BC-109-Room-1029(Postgraduate-Venue),47.31,4530.97,214360.89,8760,24.47
Law,Old_Main_Building,BC-109-Room-1018-B(Committee-Room),39.49,4530.97,178933.06,8760,20.43
Law,Old_Main_Building,BC-109-Room-1017(LectureHall),47.32,4530.97,214402.84,8760,24.48
Law,Old_Main_Building,BC-109-Room-1023(LectureHall),169.79,4530.97,769308.67,8760,87.82
Law,Old_Main_Building,BC-109-Room-1031(LectureHall),77.65,4530.97,351841.05,8760,40.16
Law,Old_Main_Building,BC-109-Room-2027(LectureHall),171.98,4530.97,779258.01,8760,88.96
Law,Old_Main_Building,BC-109-Room-2034(Lecture-Room),47.38,4530.97,214675.69,8760,24.51
Law,Old_Main_Building,BC-109-Room-1018-A(Committee-Room),10.46,4530.97,47404.12,8760,5.41
Law,Old_Main_Building,BC-109-Room-1028-B(Seminar-Room),27.82,4530.97,126063.26,8760,14.39
Medicine_and_Health_Sciences,Ukwanda_Rural_Clinic_School_Worcester,BC-2029-Room-2003-A(Balcony),NA,2076.61,NA,8760,GetAvgate/SQM
Medicine_and_Health_Sciences,Ukwanda_Rural_Clinic_School_Worcester,BC-2029-Room-2012-A(Balcony),NA,2076.61,NA,8760,GetAvgate/SQM
Medicine_and_Health_Sciences,Ukwanda_Rural_Clinic_School_Worcester,BC-2029-Room-1009-A(LectureVenue),22.63,2076.61,46998.84,8760,5.37
Medicine_and_Health_Sciences,Ukwanda_Rural_Clinic_School_Worcester,BC-2029-Room-1009(LectureVenue),21.53,2076.61,44709.29,8760,5.10
Medicine_and_Health_Sciences,Ukwanda_Rural_Clinic_School_Worcester,BC-2029-Room-1008(LectureVenue),46.81,2076.61,97215.71,8760,11.10
Medicine_and_Health_Sciences,Ukwanda_Rural_Clinic_School_Worcester,BC-2029-Room-1007(LectureVenue),43.95,2076.61,91258.6,8760,10.42
Medicine_and_Health_Sciences,Ukwanda_Rural_Clinic_School_Worcester,BC-2029-Room-1002(LectureVenue),22.21,2076.61,46124.61,8760,5.27
Medicine_and_Health_Sciences,Ukwanda_Rural_Clinic_School_Worcester,BC-2029-Room-1001(LectureVenue),43.85,2076.61,91068.32,8760,10.40
Medicine_and_Health_Sciences,Ukwanda_Rural_Clinic_School_Worcester,BC-2029-Room-1026(Committee-Room),25.77,2076.61,53507.93,8760,6.11
Medicine_and_Health_Sciences,Ukwanda_Rural_Clinic_School_Worcester,BC-2029-Room-1041-B(Committee-Room),11.09,2076.61,23037.29,8760,2.63
Medicine_and_Health_Sciences,Ukwanda_Rural_Clinic_School_Worcester,BC-2029-Room-1010(Ouditorium),160.53,2076.61,333349.61,8760,38.05
Science,Chemistry,BC-40-Room-1027(LectureHall),247.23,2096.61,518349.66,8760,59.17
Science,Chemistry,BC-40-Room-2020(LectureHall),247.25,2096.61,518395.7,8760,59.18
Science,Chemistry,BC-40-Room-1015(LectureHall),331.6,2096.61,695230.89,8760,79.36
Science,Chemistry,BC-40-Room-2011(LectureHall),335.47,2096.61,703354.41,8760,80.29
Science,Chemistry,BC-40-Room-1030(OpenPlanArea),54.95,2096.61,115208.35,8760,13.15
Science,Chemistry,BC-40-Room-2021(OpenPlanArea),55.1,2096.61,115533.46,8760,13.19
Science,Inorganic_Chemistry,BC-4-Room-2017(LectureHall),130.26,2096.61,273107.05,8760,31.18
Science,Merensky,BC-93-Room-1011(LectureHall),116.36,2096.61,243955.7,8760,27.85
Science,Merensky,BC-93-Room-2013(LectureHall),125.03,2096.61,262140.89,8760,29.92
Science,Merensky,BC-93-Room-OO67(LectureHall),221.4,2096.61,464189.66,8760,52.99
Science,Merensky,BC-93-Room-3002(LectureHall),188.89,2096.61,396022.29,8760,45.21
Science,Mike_de_Vries_Building,BC-27-Room-1040(LectureHall),56.94,2096.61,119388.36,8760,13.63
Science,Mike_de_Vries_Building,BC-27-Room-2002(LectureHall),169.61,2096.61,355604.1,8760,40.59
Science,Natural_Science,BC-100-Room-1030(LectureHall),209.03,2096.61,438248.6,8760,50.03
Science,Natural_Science,BC-100-Room-2013(Seminar-Room),49.23,2096.61,103219.22,8760,11.78
Science,Natural_Science,BC-100-Room-2020(LectureHall),123.56,2096.61,259067.01,8760,29.57
Science,Natural-Science,BC-100-Room-3004(LectureHall),166.39,2096.61,348851.54,8760,39.82
Science,Natural-Science,BC-100-Room-3005(LectureHall),97.59,2096.61,204615.29,8760,23.36
Science,Natural_Science_Glass_House,BC-89-Room-1102(Glasshouse),59.05,2096.61,123796.43,8760,14.13
Science,Natural_Science_Glass_House,BC-89-Room-1101(Lab-AA),11.37,2096.61,23837.8,8760,2.72
Science,Natural_Science_Glass_House,BC-89-Room-2087(Greenhouse),18.42,2096.61,38611.08,8760,4.41
Science,Natural_Science_Glass_House,BC-89-Room-2088(Greenhouse),18.41,2096.61,38606.56,8760,4.41
Science,Natural_Science_Glass_House,BC-89-Room-2086(Greenhouse),17.4,2096.61,36486.81,8760,4.17
Science,Natural_Science_Glass_House,BC-89-Room-2084(Greenhouse),17.43,2096.61,36553.18,8760,4.17
Science,Natural_Science_Glass_House,BC-89-Room-2078(Laboratory-Research),13.18,2096.61,27637.11,8760,3.15
Science,Natural_Science_Glass_House,BC-89-Room-2080(PlantGrowthFacilities),6.9,2096.61,14468.99,8760,1.65
Science,Natural_Science_Glass_House,BC-89-Room-1106(Glasshouse),40.95,2096.61,85856.27,8760,9.80
Science,Natural_Science_Glass_House,BC-89-Room-1100(GrowingCabinetArea-Glasshouse),74.35,2096.61,155890.86,8760,17.80
Science,Natural_Science_Glass_House,BC-89-Room-2085(LaboratoryService-Research),17.3,2096.61,36274.44,8760,4.14
Science,Natural_Science_Glass_House,BC-89-Room-2079(LaboratoryService-Research),6.88,2096.61,14414.46,8760,1.65
Science,Natural_Science_Glass_House,BC-89-Room-2082(LaboratoryService-Research),8.77,2096.61,18381.76,8760,2.10
Science,Natural_Science_Glass_House,BC-89-Room-2083(LaboratoryService-Research),9.44,2096.61,19796.64,8760,2.26
Science,Natural_Sciences_Glass_House2,BC-82-Room-1002(Glasshouse),57.38,2096.61,120294.19,8760,13.73
Science,Natural_Sciences_Glass_House2,BC-82-Room-1001(Glasshouse),51.93,2096.61,108871.23,8760,12.43
Theology,Theology_Building,BC-78-Room-2002(Murray),208.6,2909.69,606962.15,8760,69.29
Theology,Theology_Building,BC-78-Room-2003(Hofmeyer),116.71,2909.69,339581.99,8760,38.77
Theology,Theology_Building,BC-78-Room-2004(LectureHall),89.39,2909.69,260105.02,8760,29.69
Theology,Theology_Building,BC-78-Room-2051(ExhibitionArea),63.43,2909.69,184572.48,8760,21.07
Theology,Theology_Building,BC-78-Room-2031(AttievanWykAuditorium),441.68,2909.69,1285160.67,8760,146.71
Theology,Theology_Building,BC-78-Room-1003(LectureHall),88.71,2909.69,258114,8760,29.47
Theology,Theology_Building,BC-78-Room-1002(LectureHall),89.79,2909.69,261264.8,8760,29.82
Theology,Theology_Building,BC-78-Room-1006(LectureHall),70.03,2909.69,203767.1,8760,23.26
Theology,Theology_Building,BC-78-Room-1040(Chapel),74.47,2909.69,216692.7,8760,24.74
Theology,Theology_Building,BC-78-Room-2069-B(MeetingVenue),14.26,2909.69,41479.67,8760,4.74
Other Buildings,Administration_BlockB,BC-1-Room-B2206(Committee-Room),50.75,NA,NA,8760,GetAvgate/SQM
Other Buildings,Administration_BlockB,BC-1-Room-B2207(Committee-Room),91.19,NA,NA,8760,GetAvgate/SQM
Other Buildings,Administration_BlockB,BC-1-Room-B1205(Boardroom),51.68,NA,NA,8760,GetAvgate/SQM
Other Buildings,Administration_BlockB,BC-1-Room-B1218A(Meeting-Room),13.94,NA,NA,8760,GetAvgate/SQM
Other Buildings,AI_Perold,BC-65-Room-2005(Seminar-Room),59.99,NA,NA,8760,GetAvgate/SQM
Other Buildings,AI_Perold,BC-65-Room-1006(Postgraduate-Venue),26.69,NA,NA,8760,GetAvgate/SQM
Other Buildings,AI_Perold,BC-65-Room-1018(LectureHall),51.49,NA,NA,8760,GetAvgate/SQM
Other Buildings,AI_Perold,BC-65-Room-1011(Postgraduate-Venue),24.46,NA,NA,8760,GetAvgate/SQM
Other Buildings,AI_Perold,BC-65-Room-1017(Postgraduate-Venue),46.57,NA,NA,8760,GetAvgate/SQM
Other Buildings,AI_Perold,BC-65-Room-1020(Committee-Room),43.25,NA,NA,8760,GetAvgate/SQM
Other Buildings,AI_Perold,BC-65-Room-2016(Committee-Room),28.77,NA,NA,8760,GetAvgate/SQM
Other Buildings,AI_Perold,BC-65-Room-OO27(Laboratory-Teaching),46.57,NA,NA,8760,GetAvgate/SQM
Other Buildings,AI_Perold,BC-65-Room-OO30(Laboratory-Research),130.73,NA,NA,8760,GetAvgate/SQM
Other Buildings,AI_Perold,BC-65-Room-OO25(Seminar-Room),21.99,NA,NA,8760,GetAvgate/SQM
Other Buildings,AI_Perold,BC-65-Room-1013(Postgraduate-Venue),28.41,NA,NA,8760,GetAvgate/SQM
Other Buildings,Bellvista_Lodge,BC-656-Room-1046(Bar),9.14,NA,NA,8760,GetAvgate/SQM
Other Buildings,Bellvista_Lodge,BC-656-Room-1047(Toilet),3.28,NA,NA,8760,GetAvgate/SQM
Other Buildings,Bellvista_Lodge,BC-656-Room-1042(Kitchen),68.47,NA,NA,8760,GetAvgate/SQM
Other Buildings,Bellvista_Lodge,BC-656-Room-1049(Porch),52.53,NA,NA,8760,GetAvgate/SQM
Other Buildings,Bellvista_Lodge,BC-656-Room-1041(DiningHall),152.68,NA,NA,8760,GetAvgate/SQM
Other Buildings,Bellvista_Lodge,BC-656-Room-1002(Reception),16.63,NA,NA,8760,GetAvgate/SQM
Other Buildings,Bellvista_Lodge,BC-656-Room-1001(WaitingArea),10.38,NA,NA,8760,GetAvgate/SQM
Other Buildings,Bellvista_Lodge,BC-656-Room-1040(Hallway),41.21,NA,NA,8760,GetAvgate/SQM
Other Buildings,Bellvista_Lodge,BC-656-Room-1006(Flat),17.51,NA,NA,8760,GetAvgate/SQM
Other Buildings,Bellvista_Lodge,BC-656-Room-1007(Flat),17.51,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biological_Science_Study_Facility,BC-15-Room-A201(LectureHall),237.27,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biological_Science_Study_Facility,BC-15-Room-A203(LectureHall),194.5,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1058(Lobby),25.56,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1081(LectureHall),361.02,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-5048(Lecture-Room),58.65,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1003(Seminar-Room),36.86,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1006(Seminar-Room),56.27,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1007(Seminar-Room),55.2,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1008(Seminar-Room),55.2,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1009(Seminar-Room),55.46,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1013(Seminar-Room),292.63,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1016(Seminaar),42.65,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1071(Meeting-Room),47.14,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1072(Seminar),51.01,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1073(Seminar),43.18,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1074(Seminar),41.42,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1075(Seminar),42.75,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1076(Seminar),42.55,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1089(Meeting-Room),83.91,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-2073(Lecture-Room),129.6,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-2085(LectureHall),87.25,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-3073(Lecture-Room),129.6,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-3083(Lecture-Room),87.17,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-4003(Lecture-Room),129.6,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-4046(Lecture-Room),86.27,NA,NA,8760,GetAvgate/SQM
Other Buildings,Biomedical_Research_Institute_BMRI,BC-90-Room-1004(Seminar-Room),201.54,NA,NA,8760,GetAvgate/SQM
Other Buildings,Botanic_Store,BC-74-Room-1001(Store),12.74,NA,NA,8760,GetAvgate/SQM
Other Buildings,Botanical_Garden_Boiler_House,BC-9-Room-1001(Exhibition),6.91,NA,NA,8760,GetAvgate/SQM
Other Buildings,Botanical_Garden_Glasshouse1,BC-5-Room-100(Greenhouse),112.12,NA,NA,8760,GetAvgate/SQM
Other Buildings,Botanical_Garden_Glasshouse2,BC-6-Room-100(Greenhouse),112.73,NA,NA,8760,GetAvgate/SQM
Other Buildings,Botanical_Garden_Glasshouse3,BC-7-Room-100(Greenhouse),112.72,NA,NA,8760,GetAvgate/SQM
Other Buildings,Botanical_Garden_Greenhouse,BC-13-Room-100(Greenhouse),69.66,NA,NA,8760,GetAvgate/SQM
Other Buildings,Botanical_Garden_Workshop,BC-77-Room-1004(OpenWorkshop),NA,NA,NA,8760,GetAvgate/SQM
Other Buildings,Botanical_Garden_Workshop,BC-77-Room-1001(Shop),50.72,NA,NA,8760,GetAvgate/SQM
Other Buildings,Botanical_Garden_Workshop,BC-77-Room-1002(Store),11.77,NA,NA,8760,GetAvgate/SQM
Other Buildings,Botanical_Garden_Workshop,BC-77-Room-1003(OpenWorkshop),37.82,NA,NA,8760,GetAvgate/SQM
Other Buildings,Chamber_of_Mining_and_Geology,BC-46-Room-2037(Lab-Microscope),10.59,NA,NA,8760,GetAvgate/SQM
Other Buildings,Chamber_of_Mining_and_Geology,BC-46-Room-2004(LectureHall),49.69,NA,NA,8760,GetAvgate/SQM
Other Buildings,Chamber_of_Mining_and_Geology,BC-46-Room-2036(LectureHall-Practical),194.33,NA,NA,8760,GetAvgate/SQM
Other Buildings,Chamber_of_Mining_and_Geology,BC-46-Room-2028(LectureHall),59.97,NA,NA,8760,GetAvgate/SQM
Other Buildings,Chamber_of_Mining_and_Geology,BC-46-Room-1032(LectureHall),68.41,NA,NA,8760,GetAvgate/SQM
Other Buildings,Chamber_of_Mining_and_Geology,BC-46-Room-2041(LectureHall),194.28,NA,NA,8760,GetAvgate/SQM
Other Buildings,Chamber_of_Mining_and_Geology,BC-46-Room-1004(LectureHall-WPdeKock),158.99,NA,NA,8760,GetAvgate/SQM
Other Buildings,Chamber_of_Mining_and_Geology,BC-46-Room-1005(Lecture-Room-Electronics103),188.77,NA,NA,8760,GetAvgate/SQM
Other Buildings,Clinical_Building,BC-91-Room-1021(Boardroom-J.NDeVilliers),235.17,NA,NA,8760,GetAvgate/SQM
Other Buildings,Clinical_Building,BC-91-Room-1011(Committee-Room),22.73,NA,NA,8760,GetAvgate/SQM
Other Buildings,Clinical_Building,BC-91-Room-1014(Committee-Room),33.51,NA,NA,8760,GetAvgate/SQM
Other Buildings,Clinical_Building,BC-91-Room-1029-A(ReceptionArea),13.66,NA,NA,8760,GetAvgate/SQM
Other Buildings,Clinical_Building,BC-91-Room-1027(Seminar-Room),28.03,NA,NA,8760,GetAvgate/SQM
Other Buildings,Clinical_Building,BC-91-Room-1029-B(ReceptionArea),55.88,NA,NA,8760,GetAvgate/SQM
Other Buildings,Clinical_Building,BC-91-Room-OO38(Seminar-Room),43.53,NA,NA,8760,GetAvgate/SQM
Other Buildings,Clinical_Building,BC-91-Room-OO53(Studio),28.23,NA,NA,8760,GetAvgate/SQM
Other Buildings,GoldFields_Oos_Driefontein,BC-296-Room-E10(Living-Room),28.34,NA,NA,8760,GetAvgate/SQM
Other Buildings,GoldFields_Wes_Driefontein,BC-297-Room-F13(BedroomSingle),9.46,NA,NA,8760,GetAvgate/SQM
Other Buildings,GoldFields_Wes_Driefontein,BC-297-Room-F12(BedroomDouble),18.67,NA,NA,8760,GetAvgate/SQM
Other Buildings,GoldFields_Wes_Driefontein,BC-297-Room-F10(Living-Room),28.34,NA,NA,8760,GetAvgate/SQM
Other Buildings,Horse_Stable_Mariendahl,BC-542-Room-1020(HorseStable),14.96,NA,NA,8760,GetAvgate/SQM
Other Buildings,Ingangspoort_Tygerberg,BC-300-Room-1001(Security-Office),3.17,NA,NA,8760,GetAvgate/SQM
Other Buildings,Irene,BC-245-Room-1030(RecreationHall),164.93,NA,NA,8760,GetAvgate/SQM
Other Buildings,Irene,BC-245-Room-1029(StudySpace),25.56,NA,NA,8760,GetAvgate/SQM
Other Buildings,Irene,BC-245-Room-1026(StudySpace),12.4,NA,NA,8760,GetAvgate/SQM
Other Buildings,Irene,BC-245-Room-1025(StudySpace),12.4,NA,NA,8760,GetAvgate/SQM
Other Buildings,Irene,BC-245-Room-1021(Computer-Room),23.29,NA,NA,8760,GetAvgate/SQM
Other Buildings,Irene,BC-245-Room-1023(BedroomSingle),15.25,NA,NA,8760,GetAvgate/SQM
Other Buildings,Irene,BC-245-Room-1018(Circulation),18.48,NA,NA,8760,GetAvgate/SQM
Other Buildings,Irene,BC-245-Room-1019(Sitting-Room),26.34,NA,NA,8760,GetAvgate/SQM
Other Buildings,Irene,BC-245-Room-1016(BedroomSingle),14.92,NA,NA,8760,GetAvgate/SQM
Other Buildings,Irene,BC-245-Room-1017(Bathroom),4.94,NA,NA,8760,GetAvgate/SQM
Other Buildings,Irene,BC-245-Room-1059(Kiosk),58.61,NA,NA,8760,GetAvgate/SQM
Other Buildings,Monica_Residence,BC-262-Room-3028(BedroomDouble),14.05,NA,NA,8760,GetAvgate/SQM
Other Buildings,Monica_Residence,BC-262-Room-3032(Corridor),20.33,NA,NA,8760,GetAvgate/SQM
Other Buildings,Nedbank_Stellenbosch_University_Launchlab,BC-156-Room-1017(Committee-Room),40.15,NA,NA,8760,GetAvgate/SQM
Other Buildings,Nedbank_Stellenbosch_University_Launchlab,BC-156-Room-1034(Workshop),69.38,NA,NA,8760,GetAvgate/SQM
Other Buildings,Nedbank_Stellenbosch_University_Launchlab,BC-156-Room-1040(SittingArea),153.85,NA,NA,8760,GetAvgate/SQM
Other Buildings,Neelsie_Student_Centre,BC-305-Room-K04(FoodCourt),398.16,NA,NA,8760,GetAvgate/SQM
Other Buildings,Neelsie_Student_Centre,BC-305-Room-E22(WomensUnionHall),293.11,NA,NA,8760,GetAvgate/SQM
Other Buildings,Neelsie_Student_Centre,BC-305-Room-E02-2(ElectronicClassroom),68.53,NA,NA,8760,GetAvgate/SQM
Other Buildings,Neelsie_Student_Centre,BC-305-Room-E02-1(ElectronicClassroom),70.88,NA,NA,8760,GetAvgate/SQM
Other Buildings,Neelsie_Student_Centre,BC-305-Room-E01-2(ElectronicClassroom),286.22,NA,NA,8760,GetAvgate/SQM
Other Buildings,Neelsie_Student_Centre,BC-305-Room-E01-1(ElectronicClassroom),343.38,NA,NA,8760,GetAvgate/SQM
Other Buildings,Neelsie_Student_Centre,BC-305-Room-G00(Hallway),858.26,NA,NA,8760,GetAvgate/SQM
Other Buildings,Neelsie_Student_Centre,BC-305-Room-T00(Hallway),218.17,NA,NA,8760,GetAvgate/SQM
Other Buildings,Neelsie_Student_Centre,BC-305-Room-2998(Walkway),102.5,NA,NA,8760,GetAvgate/SQM
Other Buildings,Old_Conservatory,BC-70-Room-1003(Committee-Room),43.11,NA,NA,8760,GetAvgate/SQM
Other Buildings,Old_Conservatory,BC-70-Room-2000(LectureVenue),161.95,NA,NA,8760,GetAvgate/SQM
Other Buildings,Old_Conservatory,BC-70-Room-2000-A(LectureVenue-Stage),66.48,NA,NA,8760,GetAvgate/SQM
Other Buildings,SadaOms,BC-304-Room-1005(Committee-Room),13.78,NA,NA,8760,GetAvgate/SQM
Other Buildings,SadaOms,BC-304-Room-1006(TV-Room),20.78,NA,NA,8760,GetAvgate/SQM
Other Buildings,SadaOms,BC-304-Room-1004(Recreation),69.04,NA,NA,8760,GetAvgate/SQM
Other Buildings,SadaOms,BC-304-Room-1011(Dining-Room),573.62,NA,NA,8760,GetAvgate/SQM
Other Buildings,SadaOms,BC-304-Room-1001(Dining-Room),176.45,NA,NA,8760,GetAvgate/SQM
Other Buildings,Sonop,BC-240-Room-3053(BedroomSingle),9.28,NA,NA,8760,GetAvgate/SQM
Other Buildings,Sonop,BC-240-Room-3055(BedroomDouble),14.62,NA,NA,8760,GetAvgate/SQM
Other Buildings,Sonop,BC-240-Room-3054(Stair),15.56,NA,NA,8760,GetAvgate/SQM
Other Buildings,Sonop,BC-240-Room-3062(Corridor),18.28,NA,NA,8760,GetAvgate/SQM
Other Buildings,Sonop,BC-240-Room-OOO7(Study-Room),29.74,NA,NA,8760,GetAvgate/SQM
Other Buildings,Sonop,BC-240-Room-OOO5(Sitting-Room),24.92,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Library,BC-22-Room-1005(MeetingVenue),27.77,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Library,BC-22-Room-2059-G(Seminar-Room),13.49,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Library,BC-22-Room-2055(LectureHall),193.33,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Library,BC-22-Room-2001(BookshelfandSeatingArea),5085.59,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Library,BC-22-Room-2059-C(Seminar-Room),13.23,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Library,BC-22-Room-2059-B(Seminar-Room),24.96,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Library,BC-22-Room-2059-A(Seminar-Room),22.99,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Library,BC-22-Room-2059(ComputerVenue),361.87,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Museum,BC-3-Room-2010(Exhibition),49.53,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Museum,BC-3-Room-2020(Exhibition),131.66,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Museum,BC-3-Room-2014(Exhibition),42.81,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Museum,BC-3-Room-2013(Exhibition),49.53,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Museum,BC-3-Room-2012(Exhibition),38.14,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Museum,BC-3-Room-2011(Exhibition),44.03,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Museum,BC-3-Room-2021(Exhibition),239.45,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Museum,BC-3-Room-1041(LectureHall),59.46,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Museum,BC-3-Room-1018(Meeting-Room),43.71,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Museum,BC-3-Room-1023(Exhibition),31.99,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Museum,BC-3-Room-1021(Exhibition),49.53,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Museum,BC-3-Room-1020(Exhibition),44.04,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Museum,BC-3-Room-1026(Exhibition),49.53,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Museum,BC-3-Room-1027(Exhibition),49.53,NA,NA,8760,GetAvgate/SQM
Other Buildings,SU_Museum,BC-3-Room-1002(Exhibition),291.85,NA,NA,8760,GetAvgate/SQM
Other Buildings,Tygerberg_Student_Centre,BC-315-Room-1004(Gymnasium),307.88,NA,NA,8760,GetAvgate/SQM
Other Buildings,Tygerberg_Student_Centre,BC-315-Room-1015(DiningHall),435.2,NA,NA,8760,GetAvgate/SQM
Other Buildings,Tygerberg_Student_Centre,BC-315-Room-2024(SportsHall),1005.2,NA,NA,8760,GetAvgate/SQM
Other Buildings,Tygerberg_Student_Centre,BC-315-Room-2023(Gymnasium),42.5,NA,NA,8760,GetAvgate/SQM
Other Buildings,Tygerberg_Student_Centre,BC-315-Room-3014(MusicVenue),73.54,NA,NA,8760,GetAvgate/SQM
Other Buildings,Victoria_Hub,BC-271-Room-1001(RecreationHall1stFloor),285.4,NA,NA,8760,GetAvgate/SQM
Other Buildings,Victoria_Hub,BC-271-Room-2005(Boardroom),54.7,NA,NA,8760,GetAvgate/SQM
Other Buildings,Victoria_Hub,BC-271-Room-2004(Office),9.68,NA,NA,8760,GetAvgate/SQM
Other Buildings,Victoria_Hub,BC-271-Room-2001(RecreationHall2ndFloor),254.26,NA,NA,8760,GetAvgate/SQM
Other Buildings,Victoria_Hub,BC-271-Room-2007(Games-Room),9.87,NA,NA,8760,GetAvgate/SQM
Other Buildings,Victoria_Hub,BC-271-Room-2006(Office),36.71,NA,NA,8760,GetAvgate/SQM`;
