var itemcodes = `CECO-EV100
CECO-EV101
CECO-EV102
CECO-EV103
CECO-EV104
CECO-EV105
CECO-EV150
CECO-EV151
CECO-EV152
CECO-EV153
CECO-EV154
CECO-EV200
CECO-EV250
CECO-EV300
CECO-EV350
CECO-EV400
CECO-EV450
CECO-EV500
CECO-EV550
CECO-EV600
CECO-EV601
CECO-EV650
CECO-EV701
CECO-EV702
CECO-EV750
CECO-EV800
CECO-EV850
CECO-EV999`;
var itemNames = `Event Venue Hire
Event Municipal Application
Event Labour
Event Cleaning & Waste Management
CECO Management fee
Event Contingency
Event Logistics
Event Decor and Flowers
Event Toilets
Event Fences
Event Generator Hire
Event Medical
Event Safety Officer
Event Security
Event Hospitality & Catering
Event Entertainment
Event Delegation accreditation and Conference swag
Event Registration services
Event Travel Logistics
Event Accommodation (External)
Event Accommodation (CECO Guest Accommodation)
Event Marketing & Website
Event Photography and Videography
Event Audio and Visual Services
Event Gifts
Event PCO Fees
Event Other Services
Event Damages`;
var itemAbbr = `Venue
Municipal_Application
Labour
Cleaning
Management
Contingency
Logistics
Decor
Toilets
Fences
Generator
Medical
Safety
Security
Catering
Entertainment
Accreditation
Registration
Travel
Accommodation_(External)
Accommodation_(CECO_Guest_Accommodation)
Marketing_&_Website
Photography_and_Videography
Audio_and_Visual
Gifts
PCO Fees
Other
Damages`;
daysInMonth = `31
28
31
30
31
30
31
31
30
31
30
31`;
myMonths = `January
February
March
April
May
June
July
August
September
October
November
December`;