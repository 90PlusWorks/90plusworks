const mongoose = require("mongoose");


const postSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, minlength: 2, maxlength: 50 },
    title2: { type: String, required: true,  maxlength: 100 },
    uniqueNum: { type: String, required: true},
    client: { type: String, required: true, minlength: 2, maxlength: 50 },
    contactName: { type: String, required: true, minlength: 2, maxlength: 50 },
    contactEmail: { type: String, required: true, minlength: 2, maxlength: 50 },
    contactNumber: { type: String, required: true, minlength: 4, maxlength: 20 },
    body: { type: String, required: true, minlength: 2, maxlength: 5000 },
    votes: { type: Number, default: 0 },
    startmonth: {type: String, required: true},
    startday: {type: String, required: true},
    starttime: {type: String, required: true},
    endmonth: {type: String, required: true},
    endday: {type: String, required: true},
    endtime: {type: String, required: true},
    cecoevent: { type: String, minlength: 2, maxlength: 200, required: true}, //subreddit
    username: {type: String, required: true},
    //upvotes: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    //downvotes: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    //user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    //comments: [{ type: mongoose.Schema.Types.ObjectId, ref: "Comment" }],
    category: {type: String, required: true},
    group: {type: String, required: true},
    EntityToRent: {type: String, required: true},
    chargePeriod: {type: String, default: "Charge per Hour", required: true},
    PeriodsRequired: {type: String, required: true},
    strike: {type: String, required: true},
    NumberRequired: {type: String, required: true},
    CostPerHour: {type: String, required: true}
  },
  {
    timestamps: true,
    createdAt: "publishedAt",
  } // going to add createdAt, updatedAt
);

const Post = mongoose.model("Post", postSchema);

module.exports = Post;
